package com.mouri.wattwepay;

import android.os.Bundle;

import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

import java.util.Locale;

public class HomeFragment extends Fragment {
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_home, container, false);

        // Find views by their IDs in the inflated view
        EditText solution = view.findViewById(R.id.solution_screen);
        EditText rebate = view.findViewById(R.id.rebate_screen);
        TextView answer = view.findViewById(R.id.answer_screen);
        TextView rebateTotal = view.findViewById(R.id.rebate_total);
        TextView LastTotal = view.findViewById(R.id.total_screen);
        MaterialButton calcBtn = view.findViewById(R.id.calc_button);

        Toolbar myToolbar = view.findViewById(R.id.toolbar);
        myToolbar.setTitle("Watt We Pay");

        // Now you can use these views as needed
        // For example:
        calcBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String dataValue = solution.getText().toString();
                String dataRebate = rebate.getText().toString().trim();

                if(v.getId() == R.id.calc_button){
                    if (dataValue.isEmpty()) {
                        Toast.makeText(getActivity(), "Please enter the total value of Watt", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (dataRebate.isEmpty()) {
                        Toast.makeText(getActivity(), "Please enter the Rebate value", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int rebate;
                    try {
                        rebate = Integer.parseInt(dataRebate);
                    } catch (NumberFormatException e) {
                        Toast.makeText(getActivity(), "Invalid Rebate value, please enter a numeric value", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (rebate < 0 || rebate > 5) {
                        Toast.makeText(getActivity(), "Rebate value must be between 0% and 5%", Toast.LENGTH_SHORT).show();
                        return;
                    }

                    try {
                        double solutionValue = Double.parseDouble(dataValue);
                        double rebateValue = Double.parseDouble(dataRebate);
                        String formattedSolution = String.format(Locale.getDefault(), "%.2f", solutionValue);
                        solution.setText(formattedSolution);

                        double total1;
                        double total2;
                        double total3;
                        double total4;
                        double finalTotal = 0.0;
                        double Total;
                        double rebateFinal;

                        if(solutionValue <= 200){
                            total1 = solutionValue * 0.218;
                            finalTotal = total1;
                        } else if (solutionValue > 200 && solutionValue <= 300) {
                            total1 = 200 * 0.218;
                            total2 = (solutionValue - 200) * 0.334;
                            finalTotal = total1 + total2;
                        } else if (solutionValue > 300 && solutionValue <= 600) {
                            total1 = 200 * 0.218;
                            total2 = 100 * 0.334;
                            total3 = (solutionValue - 300) * 0.516;
                            finalTotal = total1 + total2 + total3;
                        } else if (solutionValue > 600) {
                            total1 = 200 * 0.218; //43.6
                            total2 = 100 * 0.334; //33.4
                            total3 = 300 * 0.516; //154.8
                            total4 = (solutionValue - 600) * 0.546;
                            finalTotal = total1 + total2 + total3 + total4;
                        }
                        rebateFinal = finalTotal * (rebateValue / (-100));
                        Total = finalTotal - (finalTotal * (rebateValue / 100));
                        String formattedFinalTotal = String.format(Locale.getDefault(), "%.2f", Total);
                        String formattedRebateTotal = String.format(Locale.getDefault(), "%.2f", rebateFinal);
                        String formattedLastTotal = String.format(Locale.getDefault(), "%.2f", finalTotal);
                        answer.setText(formattedLastTotal);
                        rebateTotal.setText(formattedRebateTotal);
                        LastTotal.setText(formattedFinalTotal);
                    }
                    catch (NumberFormatException e) {
                        Toast.makeText(getActivity(), "Invalid input, please enter a numeric value", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });

        return view;
    }
}